const express = require('express');
var bodyParser = require('body-parser');
const app = express();
var jsonParser = bodyParser.json();

//Mock bet data reciever
app.post("/betSlips", jsonParser,(req, res) => {
    //console.log(res)
    //console.log(req)
    console.log(req.body)
    //Object.keys(req.body).length
    console.log(`Number of bets: ${req.body.length}`)
    res.status(200).end()
})

app.listen(3002, function () {
    console.log('Listening for bet data')
})