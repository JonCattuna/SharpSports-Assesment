//const Bot = require("./bot.js");
const { json } = require("body-parser");
const Bot = require("./bot.js");
let bot = new Bot()


//////////////////READ BETS
var x = bot.readBets()
/////PARSE BETS
var data
data = bot.parseBets(x)
///////SEND BETS
bot.sendBets(data)