"use strict";
const { response } = require('express');
const fetch = require('node-fetch')
class Bot 
{
    constructor(){
        //pass
    } 
    
    readBets(){
        //read betslips from file
        var fs = require('fs');
        const { type } = require('os');
        var text = fs.readFileSync("betslips.txt", 'utf-8');
        let textByLine = text.split(',');
        return(textByLine);
    }

    parseBets(textByLine)
    {
        var data = {}
        
        ////////////////////////////////////////////////////////////////////////////////////////////////////
        //Create the for loop to check chunks by betID rather than by commas to apply for the whole text file
        //Create Bet objects with all of the attributes as paramters
        //set line to null at start if there is a spread or over it will change the line
        //in each inclue if statment chop up the string to only contain the neccesary information
        //set the betobjec.parameter to that new number (Bet.betId = current)
        //That is the parsed bet object
        
        ///////////////CREATING BET OBJECT///////////////
        var Bet = {
    
            bookRef: "123456",
            slipType:"single",
            slipOddsAmerican: -110,
            atRisk: 220,
            toWin: 200,
            betType: "straight",
            eventName: "Los Angeles Lakers @ Washington Wizards",
            proposition: "spread",
            position: "Washington Wizards",
            segment: null,
            line: 4.5,
            betOddsAmerican: -110,
            player: null,
            metric: null,
            incomplete: false,
            propbet: false
            
        }
        var betcounter = 1;
        for(var i = 0; i < textByLine.length; i++)
        {
            
            var temp = textByLine[i].substr(0);
            var temp2 = temp.replaceAll('"', '');
            var current = temp2.replace(':', '');
            //////////////////////BET ID (USED FOR SPLITTING)////////////
            if(current.includes('betId'))
            {
                var newBet = JSON.parse(JSON.stringify(Bet));
                data[betcounter] =  newBet;
                betcounter +=1;
                //console.log(data);
                temp = current.replace('{betId', '');
                //console.log(temp)
                Bet.bookRef = temp;
    
                //////////////////////////////////////////SLIP ATTRIBUTES////////////////////////
                Bet.slipType = null;
                Bet.toWin = null;
                Bet.atRisk = null;
                Bet.slipOddsAmerican = null;
    
                /////////////////////////////////////////BET ATTRIBUTES//////////////////////
                Bet.betOddsAmerican = null;
                Bet.betType = null;
                Bet.eventName = null;
                Bet.incomplete = false;
                Bet.line = null;
                Bet.metric = null;
                Bet.player = null;
                Bet.position = null;
                Bet.proposition = null;
                Bet.segment = null;
                Bet.propbet = false; 
                var parlayBet = false; 
            
            }
            ////////////////SLIP ODDS AMERICAN/////////
            if(current.includes('americanPrice'))
            {
                temp = current.replace('americanPrice', '');
                Bet.slipOddsAmerican = temp; 
            }
            
            ///////////////////AT RISK//////////
            if(current.includes('currentSizePerLine'))
            {
                temp = current.replace('currentSizePerLine', '');
                Bet.atRisk = temp;
            }
    
            ////////////////TO WIN/////////
            if(current.includes('originalPotentialWin'))
            {
                temp = current.replace('originalPotentialWin', '');
                Bet.toWin = temp; 
            }
    
            ///////////////////////////////// BET ATTIBUTES////////////////////////////////////////
            
            /////////////////BET TYPE (SINGLE CHECK)/////////
            if(current.includes('betTypeSGL'))
            {
                Bet.slipType = "Single Bet";
                Bet.betType = "Straight";
                parlayBet = false
            }
            
    ////////////////BET TYPE (PARLAY CHECK)///////////////////////////////////////
            if(current.includes('betTypeTBL'))
            {
                Bet.slipType = "Parlay Bet";
                Bet.betType = "Straight";
                parlayBet = true;
            }

            var legcount = 1;
            if(current.includes('marketId') && parlayBet == true)
                legcount+=1;

            if(parlayBet == true)
            {        
                for(var j = 0; j<=legcount; j++)
                {
                    
                    /////////////////PROPOSITION/////////
                        
                            if(current.includes('HANDICAP'))
                            {
                                Bet.proposition = "Spread";
                            }
                            else if (current.includes('MONEY'))
                            {
                                Bet.proposition = "Money Line";
                            }
                            else if (current.includes('PLAYER'))
                            {
                                Bet.proposition = "Player Prop";
                            }
                            else if (current.includes('PITCHER'))
                            {
                                Bet.proposition = "Player Prop";
                            }
                            else if (current.includes('TOTAL'))
                            {
                                Bet.proposition = "total";
                            }
                            else
                            {
                                Bet.incomplete = true;
                            }
                        
                        if(current.includes('marketType'))
                        {
                            if(current.includes('FIRST_HALF'))
                                Bet.segment = "First Half";
                            else if(current.includes('SECOND_HALF'))
                                Bet.segment = "Second Half";
                            else if(current.includes('FIRST_QUARTER'))
                                Bet.segment = "First Quarter";
                            else if(current.includes('SECOND_QUARTER'))
                                Bet.segment = "Second Quarter";
                                else if(current.includes('2ND_QUARTER'))
                                Bet.segment = "Second Quarter";
                            else if(current.includes('3RD_QUARTER'))
                                Bet.segment = "Third Quater";
                            else if(current.includes('FOURTH_QUARTER'))
                                Bet.segment = "Fourth Quarter";
                                else if(current.includes('4TH_QUARTER'))
                                Bet.segment = "Fourth Quarter";
                            else
                                Bet.segment = null;
                        }
                        if(current.includes('eventDescription'))
                        {
                            temp = current.replace('eventDescription', '');
                            Bet.eventName = temp;
                        }
                        if(current.includes('selectionName'))
                        {
                            temp = current.replace('selectionName', '');
                            Bet.position = temp;
                        }
                        if(current.includes('handicap'))
                        {
                            temp = current.replace('handicap', '');
                            Bet.line = temp;
                        }
                        if(current.includes('originalAmericanPrice'))
                        {
                            temp = current.replace('originalAmericanPrice', '');
                            Bet.betOddsAmerican = temp;
                        }
                        var newBet = JSON.parse(JSON.stringify(Bet));
                        data[betcounter] =  newBet;
                        betcounter +=1;
                        Bet.betOddsAmerican = null;
                        Bet.betType = null;
                        Bet.eventName = null;
                        Bet.incomplete = false;
                        Bet.line = null;
                        Bet.metric = null;
                        Bet.player = null;
                        Bet.position = null;
                        Bet.proposition = null;
                        Bet.segment = null;
                        Bet.propbet = false; 
                        
                        console.log("adding new parlay bet");
                    
                    }
                    parlayBet = false;
                
            }
            
            
    //////////////////////////////////////////////END OF PARLAY CHECKER///////////////////////
    
            /////////////////PROPOSITION/////////
            if(current.includes('marketType'))
            {
                ////////////////SPREAD ///////////////
                if(current.includes('HANDICAP'))
                {
                    Bet.proposition = "Spread";
                }
                //////////////MONEY LINE/////////
                else if (current.includes('MONEY'))
                {
                    Bet.proposition = "Money Line";
                }
                //////////////CHECK FOR PLAYER (PLAYER PROP)///////
                else if (current.includes('PLAYER'))
                {
                    Bet.proposition = "Player Prop";
                    Bet.propbet = true;
                }
                //////////////CHECK FOR PITCHER (PLAYER PROP)/////
                else if (current.includes('PITCHER'))
                {
                    Bet.proposition = "Player Prop";
                    Bet.propbet = true;
                }
                /////////TOTAL BET/////////
                else if (current.includes('TOTAL'))
                {
                    Bet.proposition = "total";
                }
                /////////////UNHANDELED//////
                else
                {
                    Bet.incomplete = true;
                }
            }
    
            ///////////////SEGMENT///////
            if(current.includes('marketType'))
            {
                if(current.includes('FIRST_HALF'))
                    Bet.segment = "First Half";
                else if(current.includes('SECOND_HALF'))
                    Bet.segment = "Second Half";
                else if(current.includes('FIRST_QUARTER'))
                    Bet.segment = "First Quarter";
                else if(current.includes('SECOND_QUARTER'))
                    Bet.segment = "Second Quarter";
                    else if(current.includes('2ND_QUARTER'))
                    Bet.segment = "Second Quarter";
                else if(current.includes('3RD_QUARTER'))
                    Bet.segment = "Third Quater";
                else if(current.includes('FOURTH_QUARTER'))
                    Bet.segment = "Fourth Quarter";
                    else if(current.includes('4TH_QUARTER'))
                    Bet.segment = "Fourth Quarter";
                else
                    Bet.segment = null;
            }
    
            //////////////EVENT NAME//////////
            if(current.includes('eventDescription'))
            {
                temp = current.replace('eventDescription', '');
                Bet.eventName = temp;
            }
    
            //////////POSITION/////////
            if(current.includes('selectionName'))
            {
                if(Bet.propbet == true)
                {
                    temp = current.replace('selectionName', '');
                    temp2 = temp.split(' ');
                    var playerName = temp2[2];
                    Bet.position = playerName;
                }
                else
                { 
                    temp = current.replace('selectionName', '');
                    Bet.position = temp;
                }
            }
    
            ////////////LINE///////////
            if(current.includes('handicap'))
            {
                temp = current.replace('handicap', '');
                Bet.line = temp;
            }
    
            ////////////BET ODDS AMERICAN//////////
            if(current.includes('originalAmericanPrice'))
            {
                temp = current.replace('originalAmericanPrice', '');
                Bet.betOddsAmerican = temp;
            }
    
    
            ////// if a prop bet /////////
            if( Bet.propbet == true)
            {
                ///////////PLAYER/////////
                if(current.includes('selectionName'))
                {
                    temp = current.replace('selectionName', '');
                    temp2 = temp.split(' ');
                    playerName = temp2[0] + " " +  temp2[1];
                    Bet.player = playerName;
                }
                //////////METRIC///////
                if(current.includes('eventMarketDescription'))
                {
                    temp = current.replace('eventMarketDescription', '');
                    var betMetric = temp.substr(temp.indexOf('-'), temp.length);
                    temp2 = betMetric.replace('-', '');
                    Bet.metric = temp2;
    
                }
            }
    
            ////////////////////////INCOMPLETE BET////////////
            if(Bet.incomplete == true)
            {
                Bet.betOddsAmerican = null;
                Bet.betType = null;
                Bet.eventName = null;
                Bet.incomplete = true;
                Bet.line = null;
                Bet.metric = null;
                Bet.player = null;
                Bet.position = null;
                Bet.proposition = null;
                Bet.segment = null;
            }
          
        }
        
        var newBet = JSON.parse(JSON.stringify(Bet));
        data[betcounter] =  newBet;
        
        var finaldata = JSON.parse(JSON.stringify(data));
        return(finaldata);
    }

    async sendBets(url, data)
    {
        ////////////////////using Fetch so send the list of objects to the server
        const fetch = require('node-fetch');
        var Betdata = this.parseBets(this.readBets());
            url = 'http://localhost:3002/betSlips'
            const res = await fetch(url,{method:'POST',body:JSON.stringify(Betdata),headers: { 'Content-Type': 'application/json' }});
   
    }
    
}

module.exports = Bot;

            